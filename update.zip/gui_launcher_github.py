import os
import subprocess
import threading
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import sys
import requests
import zipfile

# Update check URLs
REMOTE_VERSION_URL = "https://raw.githubusercontent.com/korabavdiu/verizon-mop-updates/refs/heads/main/version.txt?token=GHSAT0AAAAAAC3J2KTFR5SWCJ25EERZL26SZ2NYIBQ"
UPDATE_FILE_URL = "https://raw.githubusercontent.com/korabavdiu/verizon-mop-updates/main/update.zip"

CURRENT_VERSION = "1.0"  # Update this with your current app version

def resource_path(relative_path):
    """Get the absolute path to the resource, works for development and for PyInstaller bundle."""
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# Auto-update functions
def check_for_updates():
    """Check if a newer version is available."""
    try:
        print("Checking for updates...")
        response = requests.get(REMOTE_VERSION_URL)
        response.raise_for_status()  # Raise an error if the request fails
        remote_version = response.text.strip()

        if remote_version > CURRENT_VERSION:
            print(f"New version available: {remote_version}")
            return True, remote_version
        else:
            print("No updates available.")
            return False, CURRENT_VERSION
    except Exception as e:
        print(f"Error checking for updates: {e}")
        return False, CURRENT_VERSION

def download_update():
    """Download the update file."""
    try:
        print("Downloading update...")
        response = requests.get(UPDATE_FILE_URL, stream=True)
        response.raise_for_status()

        with open("update.zip", "wb") as update_file:
            for chunk in response.iter_content(chunk_size=8192):
                update_file.write(chunk)

        print("Update downloaded successfully.")
        return True
    except Exception as e:
        print(f"Error downloading update: {e}")
        return False

def install_update():
    """Install the downloaded update."""
    try:
        print("Installing update...")
        with zipfile.ZipFile("update.zip", "r") as zip_ref:
            zip_ref.extractall(".")  # Extract the contents to the current directory
        os.remove("update.zip")  # Clean up the update file
        print("Update installed successfully!")
        return True
    except Exception as e:
        print(f"Error installing update: {e}")
        return False

# Existing tool functions remain unchanged
def run_tool(tool_name):
    """Run the specified tool."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    tool_path = os.path.join(script_dir, tool_name)
    print(f"Running tool: {tool_path}")  # Debug statement
    if not os.path.isfile(tool_path):
        messagebox.showerror("Error", f"File not found: {tool_name}")
        print(f"File not found: {tool_name}")  # Debug statement
        return
    try:
        result = subprocess.run([tool_path], check=True)
        print(f"Tool finished with return code: {result.returncode}")  # Debug statement
    except subprocess.CalledProcessError as e:
        messagebox.showerror("Error", f"Error running {tool_name}: {e}")
        print(f"Error: {e}")  # Debug statement
    except Exception as e:
        messagebox.showerror("Error", f"An unexpected error occurred: {e}")
        print(f"Unexpected error: {e}")  # Debug statement

def run_tool_threaded(tool_name):
    """Run the specified tool in a separate thread."""
    threading.Thread(target=run_tool, args=(tool_name,)).start()

# Button click handlers remain unchanged
def on_tool1_click():
    print("Tool 1 button clicked")  # Debug statement
    run_tool_threaded("FTOOLi.exe")

def on_tool2_click():
    print("Tool 2 button clicked")  # Debug statement
    run_tool_threaded("ge-xe-tool.exe")

def on_tool3_click():
    print("Tool 3 button clicked")  # Debug statement
    run_tool_threaded("9k-mx conversion.exe")

def on_tool4_click():
    print("Tool 4 button clicked")  # Debug statement
    run_tool_threaded("dual-uplink-generator.exe")

def on_tool5_click():
    print("Tool 5 button clicked")  # Debug statement
    run_tool_threaded("9k-to-ciena.exe")

def on_tool6_click():
    """Handler for Alcatel to ACX button click."""
    print("Tool 6 button clicked")  # Debug statement
    run_tool_threaded("alcatel-to-acx.exe")

def main():
    """Main function to create and run the GUI application."""
    # Auto-update check
    update_available, remote_version = check_for_updates()
    if update_available:
        if messagebox.askyesno("Update Available", f"Version {remote_version} is available. Do you want to update now?"):
            if download_update() and install_update():
                messagebox.showinfo("Update Complete", f"Updated to version {remote_version}. Restarting...")
                os.execl(sys.executable, sys.executable, *sys.argv)
            else:
                messagebox.showerror("Update Failed", "Failed to update. Please try again later.")

    root = tk.Tk()
    root.title("Verizon MOP Generator")
    root.geometry("400x600")  # Adjusted window size to make room for the flag

    # Minimalist dark theme setup
    root.configure(bg="#1A1A1A")  # Dark black background

    # Create a style for ttk widgets with dark theme
    style = ttk.Style()
    style.configure('TButton',
                    font=('Arial', 12),
                    padding=10,
                    relief="flat",
                    background="#333333",  # Light dark button color
                    foreground="black")  # Black text
    style.map('TButton', background=[('active', '#4A4A4A')])  # Slightly lighter button when active

    frame = tk.Frame(root, padx=20, pady=20, bg="#1A1A1A")
    frame.pack(expand=True)

    # Load the flag image
    try:
        flag_image_path = resource_path("circle-verizon-png-image.png")
        if not os.path.exists(flag_image_path):
            print(f"Error: Flag image not found at path {flag_image_path}")
            raise FileNotFoundError("Flag image not found")

        flag_image = Image.open(flag_image_path)
        flag_image = flag_image.resize((90, 90), Image.Resampling.LANCZOS)
        flag_photo = ImageTk.PhotoImage(flag_image)

        flag_label = tk.Label(root, image=flag_photo, bg="#1A1A1A")
        flag_label.image = flag_photo
        flag_label.pack(pady=10)

    except Exception as e:
        print(f"Error loading the flag: {e}")
        messagebox.showerror("Error", f"Could not load the flag: {e}")

    # Buttons with minimalistic dark theme
    tool1_button = ttk.Button(frame, text="ALU to QFX", command=on_tool1_click, width=20)
    tool1_button.pack(pady=10)

    tool4_button = ttk.Button(frame, text="ALU to QFX - Dual uplink", command=on_tool4_click, width=20)
    tool4_button.pack(pady=10)

    tool2_button = ttk.Button(frame, text="QFX ge-to-xe", command=on_tool2_click, width=20)
    tool2_button.pack(pady=10)

    tool3_button = ttk.Button(frame, text="9k-to-MX", command=on_tool3_click, width=20)
    tool3_button.pack(pady=10)

    tool5_button = ttk.Button(frame, text="9k-to-Ciena", command=on_tool5_click, width=20)
    tool5_button.pack(pady=10)

    tool6_button = ttk.Button(frame, text="ALU to ACX", command=on_tool6_click, width=20)
    tool6_button.pack(pady=10)

    exit_button = ttk.Button(frame, text="Exit", command=root.quit, width=20)
    exit_button.pack(pady=10)

    root.mainloop()

if __name__ == "__main__":
    main()
